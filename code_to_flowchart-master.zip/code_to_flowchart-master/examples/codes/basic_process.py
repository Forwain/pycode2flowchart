a = 7
a = a + 1
b = a - 1