a = input()
b = a - 1
c = input()
b = b + c
print(b)