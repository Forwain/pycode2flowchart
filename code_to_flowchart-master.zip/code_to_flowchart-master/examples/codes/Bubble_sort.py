i=1
while i<n:
    j=1
    while j<n:
        if A[j]>A[j+1]
            Swap A[j] and A[j+1]
    j++
i++

