print("List Iteration") 
l = ["geeks", "for", "geeks"] 
for i in l: 
    print(i) 
