age = input()
if age < 18:
    print("no voting for u")
else:
    print("go vote lmao")