reps = input()
while reps > 0:
    print("performing repetitive task")
    reps = reps - 1
print("all done")