n = input()
if n == 2 :
    while n != 20 :
        print(n)

if n == 3 :
    while n != 30 :
        print(n)
        n = n+3

if n == 4 :
    while n !=40 :
        print(n)
        n = n+4

print"table done"


