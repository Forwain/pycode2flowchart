a = input()
if a == 3.14:
    print("a is close to pi")