# code_to_flowchart
TThe program will take as input - code, algorithm, workflow or manual and will give as output- a flowchart for it.
The code is written in python,I am using pygame for displaying flowchart.
first flowchart.py with some program as input frr eg: "python3 flowchart.py bubble_sort.py t.flow" , then python3 python3 viszulaizer.py t.flow
